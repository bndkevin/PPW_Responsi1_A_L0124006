// Nama : BENEDHICTUS KEVIN DONI BRILLIAN EVEREST
// NIM  : L0124006

$(document).ready(function() {
    // =============================================
    // SMOOTH SCROLL FOR NAVIGATION LINKS
    // =============================================
    $('.navbar__links a[href^="#"]').on('click', function(e) {
        const target = $(this).attr('href');
        const $targetElement = $(target);

        if ($targetElement.length === 0) {
            return;
        }

        e.preventDefault();
        const offset = $targetElement.offset().top - 80; // Offset for sticky nav

        $('html, body').animate({
            scrollTop: offset
        }, 800, 'swing');
    });

    // =============================================
    // FADE-IN ANIMATION ON SCROLL
    // =============================================
    function checkScroll() {
        $('.section').each(function() {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();

            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('fade-in');
            }
        });
    }

    // Initial check
    checkScroll();

    // Check on scroll
    $(window).on('scroll', function() {
        checkScroll();
    });

    // =============================================
    // ENHANCED MENU CARD HOVER EFFECTS
    // =============================================
    $('.menu-card').hover(
        function() {
            $(this).find('.menu-card__icon').animate({
                fontSize: '3.2rem',
                rotate: '5deg'
            }, 300);

            $(this).find('.menu-card__name').animate({
                color: '#c89b4a'
            }, 300);
        },
        function() {
            $(this).find('.menu-card__icon').animate({
                fontSize: '2.8rem',
                rotate: '0deg'
            }, 300);

            $(this).find('.menu-card__name').animate({
                color: '#2c1a0e'
            }, 300);
        }
    );

    // =============================================
    // MENU CARD CLICK MODAL
    // =============================================
    $('.menu-card').on('click', function() {
        const name = $(this).find('.menu-card__name').text();
        const desc = $(this).find('.menu-card__desc').text();
        const price = $(this).find('.menu-card__price').text();
        const icon = $(this).find('.menu-card__icon').text();

        // Create modal HTML
        const modalHtml = `
            <div class="modal-overlay">
                <div class="modal-content">
                    <div class="modal-close">&times;</div>
                    <div class="modal-icon">${icon}</div>
                    <h2 class="modal-title">${name}</h2>
                    <p class="modal-desc">${desc}</p>
                    <div class="modal-price">${price}</div>
                    <button class="modal-order-btn">Pesan Sekarang</button>
                </div>
            </div>
        `;

        $('body').append(modalHtml);

        // Animate modal in
        $('.modal-overlay').fadeIn(300);
        $('.modal-content').animate({
            scale: 1,
            opacity: 1
        }, 300);

        // Close modal
        $('.modal-close, .modal-overlay').on('click', function() {
            $('.modal-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        });
    });

    // =============================================
    // TESTIMONIALS CAROUSEL
    // =============================================
    let currentTestimonial = 0;
    const testimonials = $('.testi-card');
    const totalTestimonials = testimonials.length;

    // Hide all testimonials except first
    testimonials.hide();
    testimonials.eq(0).show();

    // Auto-rotate testimonials
    setInterval(function() {
        testimonials.eq(currentTestimonial).fadeOut(500, function() {
            currentTestimonial = (currentTestimonial + 1) % totalTestimonials;
            testimonials.eq(currentTestimonial).fadeIn(500);
        });
    }, 4000);

    // Add navigation dots
    const dotsHtml = '<div class="testimonial-dots"></div>';
    $('.testimonials__grid').after(dotsHtml);

    for (let i = 0; i < totalTestimonials; i++) {
        $('.testimonial-dots').append(`<span class="dot ${i === 0 ? 'active' : ''}" data-index="${i}"></span>`);
    }

    // Dot click handler
    $('.dot').on('click', function() {
        const index = $(this).data('index');
        if (index !== currentTestimonial) {
            testimonials.eq(currentTestimonial).fadeOut(300);
            testimonials.eq(index).fadeIn(300);
            currentTestimonial = index;

            $('.dot').removeClass('active');
            $(this).addClass('active');
        }
    });

    // =============================================
    // HERO STATS COUNTER ANIMATION
    // =============================================
    function animateCounters() {
        $('.stat__number').each(function() {
            const $this = $(this);
            const target = parseInt($this.text().replace(/[^\d]/g, ''));
            const suffix = $this.text().replace(/[\d]/g, '');

            $({ count: 0 }).animate({ count: target }, {
                duration: 2000,
                easing: 'swing',
                step: function() {
                    $this.text(Math.floor(this.count) + suffix);
                },
                complete: function() {
                    $this.text(target + suffix);
                }
            });
        });
    }

    // Trigger counter animation when hero is visible
    const heroObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
                heroObserver.unobserve(entry.target);
            }
        });
    });

    heroObserver.observe($('.hero')[0]);

    // =============================================
    // SOCIAL BUTTONS HOVER ANIMATION
    // =============================================
    $('.social-btn').hover(
        function() {
            $(this).animate({
                scale: 1.1,
                rotate: '5deg'
            }, 200);
        },
        function() {
            $(this).animate({
                scale: 1,
                rotate: '0deg'
            }, 200);
        }
    );

    // =============================================
    // CTA BUTTON PULSE ANIMATION
    // =============================================
    function pulseAnimation() {
        $('.navbar__cta').animate({
            boxShadow: '0 0 20px rgba(200, 155, 74, 0.6)'
        }, 1000).animate({
            boxShadow: '0 4px 16px rgba(200, 155, 74, 0.35)'
        }, 1000, pulseAnimation);
    }

    setTimeout(pulseAnimation, 2000);
});